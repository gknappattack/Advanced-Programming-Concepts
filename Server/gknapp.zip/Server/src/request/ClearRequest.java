package request;

public class ClearRequest {
    /**
     * The constuctor for the ClearRequest class initializes a request to send to the ClearService class in order
     * to execute a clearing of all the values stored in the database.
     */
    public ClearRequest() {}
}
